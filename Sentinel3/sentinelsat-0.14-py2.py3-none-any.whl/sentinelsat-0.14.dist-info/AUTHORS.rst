Creator
=======

* Marcel Wille `@willemarcel <https://github.com/willemarcel>`_

Maintainers
===========

* Kersten Clauss `@Fernerkundung <https://github.com/Fernerkundung>`_
* Martin Valgur `@valgur <https://github.com/valgur>`_
* Jonas Sølvsteen `@j08lue <https://github.com/j08lue>`_

Contributors
============

* Luca Delucchi `@lucadelu <https://github.com/lucadelu>`_
* Gaston Keller `@gkeller2 <https://github.com/gkeller2>`_
* Malte `@temal- <https://github.com/temal->`_
* unnic `@unnic <https://github.com/unnic>`_
* Leonard Kioi kinyanjui `@lenniezelk <https://github.com/lenniezelk>`_
* Schlump `@Schlump <https://github.com/Schlump>`_
* Caio Castro `@caiocacastro <https://github.com/caiocacastro>`_
* martinber `@martinber <https://github.com/martinber>`_
* Nicklas Keck `@NiklasKeck <https://github.com/NiklasKeck>`_
* Scott Staniewicz `@scottstanie <https://github.com/scottstanie>`_
* Andrey Raspopov `@Andrey-Raspopov <https://github.com/Andrey-Raspopov>`_
* Patrick Salembier `@psal93 <https://github.com/psal93>`_
* Viktor Bahr `@viktorbahr <https://github.com/viktorbahr>`_
* `@dwlsalmeida <https://github.com/dwlsalmeida>`_
* Gerald Baier `@gbaier <https://github.com/gbaier>`_
* Olga Chebotaryova `@OlgaCh <https://github.com/OlgaCh>`_
* Lukas Bindreiter `@lukasbindreiter <https://github.com/lukasbindreiter>`_
* `@yepremyana <https://github.com/yepremyana>`_
* Sarah Floris `@sdf94 <https://github.com/sdf94>`_

